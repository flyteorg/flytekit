# This file has been moved to flytekit.interactive.constants
# Import flytekit.interactive module to keep backwards compatibility
from flytekit.interactive.constants import EXIT_CODE_SUCCESS, HOURS_TO_SECONDS, MAX_IDLE_SECONDS  # noqa: F401
