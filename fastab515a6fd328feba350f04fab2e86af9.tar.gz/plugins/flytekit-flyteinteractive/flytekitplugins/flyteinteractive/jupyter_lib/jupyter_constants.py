EXAMPLE_JUPYTER_NOTEBOOK_NAME = "flyteinteractive-notebook.ipynb"
