from datetime import datetime
from flytekit import task, workflow, LaunchPlan, CronSchedule


@task
def say_hello(name: str, t: datetime) -> str:
    return f"Hello {name} {t}"


@workflow
def talker(name: str, t: datetime) -> str:
    return say_hello(name=name, t=t)


example_launch_plan = LaunchPlan.get_or_create(
    name="talk-every-minute",
    workflow=talker,
    default_inputs={"name": "Flyte"},
    schedule=CronSchedule(
        schedule="* * * * *",  # Following schedule runs every min
        kickoff_time_input_arg="t",
    ),
)
