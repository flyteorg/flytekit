import IPython  # type: ignore  # noqa  # import ipython to make

from whylogs.viz.jupyter_notebook_viz import NotebookProfileVisualizer

__ALL__ = [
    # column
    NotebookProfileVisualizer
]
